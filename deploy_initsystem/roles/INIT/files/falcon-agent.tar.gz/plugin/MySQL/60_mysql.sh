#!/bin/sh
######################################
# Mon Aug 29 09:30:18 UTC 2016
# by marten wang
######################################

function datamodel(){
        local endpoint=$(hostname)
        local metric=$4
        local tags=$1
        local value=$2
        local types=$3
	local y=$5
        echo -e '\t{
                "metric": "'$metric'",
                "endpoint": "'$endpoint'",
                "tags": "'$tags'",
                "value": "'$value'",
                "timestamp": '`date +%s`',
                "counterType": "'$types'",
                "step": 60
             '
	if [[ $y -gt 1 ]];then
		echo  -e '\t},'
	else
		echo -e '\t}'
	fi

}




####全局变量定义
#mysqluser="root"
#mysqlpass="123456"
mysqluser="zabbixMon"
mysqlpass="zbMon2015@gg"
mysqlhost="127.0.0.1"
mysqlport="3306"



####取数据
#mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show processlist' |awk '$1 !~ /Id/ && $6 !~ /Dump/'|awk '{print $2,$3,$4,$6,$5}' > mysql.tmp 2>/dev/null
BASH_V=$(echo $BASH_VERSION |awk -F '.' '{print $1}')
if [[ ! $BASH_V -lt 4 ]];then
	declare -A A
else
	declare -a B
fi

#是否存活
A['mysql_alive_local']=1
B[1]='mysql_alive_local--'1
mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'exit' >/dev/null 2>&1
if [[ $? -ne 0 ]];then
    A['mysql_alive_local']=0
        B[1]='mysql_alive_local--'0
	echo  "[" 
	datamodel 'port='$mysqlport'host='$mysqlhost 0 'GAUGE' 'mysql_alive_local' 1
	echo  "]"
	exit
fi

#连接数
A['Connect_threads']=0
B[0]='Connect_threads--'1
pro=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show processlist' |awk '$1 !~ /Id/ && $6 !~ /Dump/'|awk '{print $2,$3,$4,$6,$5}' |wc -l)
if [[ "X$pro" != "X" ]];then
	A['Connect_threads']=$pro	
	B[0]='Connect_threads--'$pro
fi

#Slave_SQL_Running
Slave_SQL_Running=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show slave status\G' |grep 'Slave_SQL_Running:' |awk -F ':' '{print $2}'i |sed 's/^ //g')             
if [[ -n "$Slave_SQL_Running" ]];then
	A['Slave_SQL_Running']=1
	B[2]='Slave_SQL_Running--1'
	if [[ "$Slave_SQL_Running" == "Yes" ]];then
		B[2]='Slave_SQL_Running--0'
        A['Slave_SQL_Running']=0
	fi
fi


#Slave_IO_Running
Slave_IO_Running=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show slave status\G' |grep 'Slave_IO_Running:' |awk -F ':' '{print $2}' |sed 's/^ //g')
if [[ -n "$Slave_IO_Running" ]];then
	A['Slave_IO_Running']=1
	B[3]='Slave_IO_Running--1'
	if [[ "$Slave_IO_Running" == "Yes" ]];then
		B[3]='Slave_IO_Running--0'
        A['Slave_IO_Running']=0
	fi
fi



#sql_time 最长执行时间
A['Sql_Time']=0
B['4']='Sql_Time--0'
sql_time=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show processlist' |awk '$1 !~ /Id/ && $6 !~ /Dump/' |awk '$5 ~ /Query/' |sort -k 6 -rn  |head -1 |awk '{print $6}')
if [[ "X$sql_time" != "X" ]];then
        A['Sql_Time']=$sql_time
	B[4]='Sql_Time--'$sql_time
fi


#drop database
A['Com_drop_db']=0
B[5]='Com_drop_db--0'
drop_database=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show status' |grep  'Com_drop_db' |awk '{print $2}')
if [[ "X$Com_drop_db" != "X" ]];then
        A['Com_drop_db']=$Com_drop_db
        B[5]='Com_drop_db--'$Com_drop_db
fi

#drop table
A['Com_drop_table']=0
B[6]='Com_drop_table--0'
Com_drop_table=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show status' |grep  'Com_drop_table' |awk '{print $2}')
if [[ "X$Com_drop_table" != "X" ]];then
        A['Com_drop_table']=$Com_drop_table
        B[6]='Com_drop_table--'$Com_drop_table
fi

#Com_truncate
A['Com_truncate']=0
B[11]='Com_truncate--0'
Com_truncate=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show status' |grep  'Com_truncate' |awk '{print $2}')
if [[ "X$Com_truncate" != "X" ]];then
        A['Com_truncate']=$Com_truncate
        B[11]='Com_truncate--'$Com_truncate
fi

#rename_table
A['Com_rename_table']=0
B[7]='Com_rename_table--0'
Com_rename_table=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show status' |grep  'Com_rename_table' |awk '{print $2}')
if [[ "X$Com_rename_table" != "X" ]];then
        A['Com_rename_table']=$Com_rename_table
        B[7]='Com_rename_table--'$Com_rename_table
fi

#Com_drop_index
A['Com_drop_index']=0
B[8]='Com_drop_index--0'
Com_drop_index=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show status' |grep  'Com_drop_index' |awk '{print $2}')
if [[ "X$Com_drop_index" != "X" ]];then
        A['Com_drop_index']=$Com_drop_index
        B[8]='Com_drop_index--'$Com_drop_index
fi



#sleep 超过200
#连接数
A['Connect_sleep_thread']=0
B[9]='Connect_sleep_thread--0'
Sleep_process_sql=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show processlist' |awk '$1 !~ /Id/ && $6 !~ /Dump/'|awk '$5~/Sleep/' |wc -l)
if [[ "X$Sleep_process_sql" != "X" ]];then
        A['Connect_sleep_thread']=$Sleep_process_sql
        B[9]='Connect_sleep_thread--'$Sleep_process_sql
fi


#主从落后
Seconds_Behind_Master=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show slave status\G' |grep 'Seconds_Behind_Master' |awk -F ':' '{print $2}')
if [[ -n "$Seconds_Behind_Master" ]];then
	A['Seconds_Behind_Master']=0
	B[10]='Seconds_Behind_Master--0'
	if [[ "X$Seconds_Behind_Master" != "X" ]];then
	        A['Seconds_Behind_Master']=$Seconds_Behind_Master
	        B[10]='Seconds_Behind_Master--'$Seconds_Behind_Master
	fi
fi




#格式输出
echo "["

if [[ ! $BASH_V -lt 4 ]];then
	len=${#A[@]}
	for key in ${!A[*]}
	do
		dtype="GAUGE"
		echo $key |grep -E "Com_drop_db|Com_drop_table|Com_truncate|Com_drop_index" >/dev/null
		if [[ $? -eq 0 ]];then
			dtype="COUNTER"
		fi

	        tags="port="$mysqlport',host='$mysqlhost
	        value=${A[$key]}
	        datamodel $tags $value $dtype $key $len
		(( len-- ))
	done
else
	len4=12
	for (( i=0; i < $len4 ;i++))
	do
		key=$(echo ${B[$i]} |awk -F '--' '{print $1}')
		if [[ ! "X"$key == "X" ]];then
			dtype="GAUGE"
			echo $key |grep -E "Com_drop_db|Com_drop_table|Com_truncate|Com_drop_index" >/dev/null
			if [[ $? -eq 0 ]];then
				dtype="COUNTER"
			fi
			tags="port="$mysqlport',host='$mysqlhost
			value=$(echo ${B[$i]} |awk -F '--' '{print $2}')
			datamodel $tags $value $dtype $key $(( $len4 - $i ))
		fi
	done
fi
echo "]"

