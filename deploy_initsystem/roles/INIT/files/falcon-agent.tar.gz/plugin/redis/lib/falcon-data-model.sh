#!/bin/sh

#####定义输出的数据模型

function datamodel(){
        local endpoint=$1
        local metric=$2
        local tags=$3
        local value=$4
        local types=$5
        echo -e '\t{
            	"metric": "'$metric'",
                "endpoint": "'$endpoint'",
                "tags": "'$tags'",
                "value": "'$value'",
                "timestamp": '`date +%s`',
                "counterType": "'$types'",
                "step": 60'
	echo -n -e '\t}'

}
