#!/bin/sh

for port in $(ps -ef|grep redis-server |grep -v grep |awk '{split($9,d,":");print d[2]}')
do

        if [[ $port =~ "1.*" ]];then
		echo "ss"
	fi
        redis_host_new='127.0.0.1###'$port'###6e1KWyC29w'
	if [[ 'X'$redis_host == 'X' ]];then
                redis_host=$(echo $redis_host_new)
        else
                redis_host=$(echo -e ${redis_host}'\n'$redis_host_new)
        fi
done




