#!/bin/sh
######################################
# Mon Aug 29 09:30:18 UTC 2016
# by marten wang
######################################

function datamodel(){
	local endpoint=$(hostname)
	local tags=$1
	local value=$2
	echo "{
		'metric': 'sys.disk.rw',
        	'endpoint': '$endpoint',
		'tags': '$tags',
		'value': $value,
		'timestamp': `date +%s`,
		'counterType': 'GAUGE',
		'step': 60
	      }
	     "

}

echo "["

while read part
do
	Array=($part)
	touch ${Array[${#Array[@]} - 1]}/just_for_check_disk_rw_file > /dev/null 2>&1 
	if [[ $? -ne 0 ]];then
		value=-1
	else
		value=1
	fi
	
	tag="fstype="${Array[1]}",mount="${Array[6]}
	datamodel $tag $value 
	
done <<< "$(df -Th |grep '%' |grep -v 'Use')"

echo "]"
