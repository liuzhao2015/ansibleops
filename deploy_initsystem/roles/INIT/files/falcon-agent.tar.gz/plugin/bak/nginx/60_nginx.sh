#!/bin/sh
######################################
# Mon Aug 29 09:30:18 UTC 2016
# by marten wang
######################################

function datamodel(){
	local endpoint=$(hostname)
	local metric=$4
	local tags=$1
	local value=$2
	local types=$3
	echo "{
		'metric': '$metric',
        	'endpoint': '$endpoint',
		'tags': '$tags',
		'value': $value,
		'timestamp': `date +%s`,
		'counterType': '$types',
		'step': 60
	      }
	     "

}

echo "["

#####获取数据########
array=$(curl "http://127.0.0.1/ngx_status" -s)  
array=(echo $array)

#####定义变量########

declare -A A
A['AC']=${array[3]}
A['ACCEPT']=${array[9]}
A['HANDLE']=${array[10]}
A['REQUEST']=${array[11]}
A['T_TIME']=${array[12]}
A['Reading']=${array[14]}
A['Writing']=${array[16]}
A['Waiting']=${array[18]}

#####端口#####
n=$(ss -antl |grep ':::80' |grep -v grep |wc -l )
A['Alive_port']=0
if [[ $n -gt 0 ]];then 
	A['Alive_port']='1'
fi

#####进程数######
num=$(ps -ef|grep nginx |grep -v grep |wc -l)
A['P_NUM']=$num

for key in ${!A[*]}
do
	tags="item=$key"
	value=${A[$key]}
	datamodel $tags $value "GAUGE" "nginx"
done 

echo "]"
