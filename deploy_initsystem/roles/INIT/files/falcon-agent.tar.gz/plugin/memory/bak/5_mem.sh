#/bin/sh


#echo  $(date +"%Y%m%d %H:%M:%S")  >> mem.tmp
#ps aux |awk '{A[$11]=A[$11]+$4}END{for(x in A)print A[x] "\t" x}' |sort -rn  |head -5 >> mem.tmp
echo '[{"endpoint": "host01", "tags": "", "timestamp": 1431349763, "metric": "sys.ntp.offset", "value": 0.73699999999999999, "counterType": "GAUGE", "step": 600}]'
