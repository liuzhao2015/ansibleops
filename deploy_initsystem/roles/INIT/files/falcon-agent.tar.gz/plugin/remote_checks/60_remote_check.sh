#!/bin/sh
######################################
# Mon Aug 29 09:30:18 UTC 2016
# by marten wang
######################################

###路径回归
cd $(dirname $0)

###检测redis
sh ./redis/60_redis.sh
