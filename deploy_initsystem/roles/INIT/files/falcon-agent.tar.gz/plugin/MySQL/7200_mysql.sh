#!/bin/sh
######################################
# Mon Aug 29 09:30:18 UTC 2016
# by marten wang
######################################

function datamodel(){
        local endpoint=$(hostname)
        local metric=$4
        local tags=$1
        local value=$2
        local types=$3
	local y=$5
        echo -e '\t{
                "metric": "'$metric'",
                "endpoint": "'$endpoint'",
                "tags": "'$tags'",
                "value": "'$value'",
                "timestamp": '`date +%s`',
                "counterType": "'$types'",
                "step": 7200
             '
	if [[ $y -gt 1 ]];then
		echo  -e '\t},'
	else
		echo -e '\t}'
	fi

}




####全局变量定义
#mysqluser="root"
#mysqlpass="123456"
mysqluser="zabbixMon"
mysqlpass="zbMon2015@gg"
mysqlhost="127.0.0.1"
mysqlport="3306"


###判断bash版本，定义不同的数据结构类型
BASH_V=$(echo $BASH_VERSION |awk -F '.' '{print $1}')
if [[ ! $BASH_V -lt 4 ]];then
        declare -A A
else
        declare -a B
fi



#自增id
A['Auto_incre']=0
B[0]='Auto_incre--0'
Auto_incre=$(mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e " select \
					round((t.auto_increment/m.max_value)*100,2) as pct_of_values_used \
						from information_schema.tables t \
  						inner join information_schema.columns c  \
    					on c.table_Schema = t.table_Schema and c.table_name = t.table_name \
  						inner join test.max_int_values m  \
    					on m.int_type = substr(c.column_type,1,length(m.int_type)) \
    					and ((m.extra like '%unsigned') = (c.column_type like '%unsigned')) \
						where c.extra = 'auto_increment' \
						order by pct_of_values_used desc limit 1; " -s |tail -1 )

if [[ "X$Auto_incre" != "X" ]];then
	n=$(echo  "$Auto_incre * 100" |bc)
	X=$(echo  "$Auto_incre - 0" |bc)
	if [[ $n > 100 ]];then
		if [[ ! $BASH_V -lt 4 ]];then
		        A['Auto_incre']=$X
		else
		        B[0]='Auto_incre--'$X
		fi
      		
      		
	fi
fi




#格式输出
echo "["

if [[ ! $BASH_V -lt 4 ]];then
	len=${#A[@]}
	for key in ${!A[*]}
	do
		dtype="GAUGE"
		echo $key |grep -E "Com_drop_db|Com_drop_table|Com_truncate|Com_drop_index" >/dev/null
		if [[ $? -eq 0 ]];then
			dtype="COUNTER"
		fi

	        tags="port="$mysqlport',host='$mysqlhost
	        value=${A[$key]}
	        datamodel $tags $value $dtype $key $len
		(( len-- ))
	done
else
	len4=1
	for (( i=0; i < $len4 ;i++))
	do
		key=$(echo ${B[$i]} |awk -F '--' '{print $1}')
		if [[ ! "X"$key == "X" ]];then
			dtype="GAUGE"
			echo $key |grep -E "Com_drop_db|Com_drop_table|Com_truncate|Com_drop_index" >/dev/null
			if [[ $? -eq 0 ]];then
				dtype="COUNTER"
			fi
			tags="port="$mysqlport',host='$mysqlhost
			value=$(echo ${B[$i]} |awk -F '--' '{print $2}')
			datamodel $tags $value $dtype $key $(( $len4 - $i ))
		fi
	done
fi
echo "]"