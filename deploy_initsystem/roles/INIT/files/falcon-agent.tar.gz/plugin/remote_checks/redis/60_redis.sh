#!/bin/sh

###路径回归
cd $(dirname $0)

###加载类库
. ./lib/falcon-data-model.sh
. ./bin/check_redis.sh
. ./conf/redis_moni_conf.sh


####FORMAT OUTPUT

function get_host_redis(){
	local redis_host=($redis_host)
	echo  -e "["
	hl=1
	for instance in ${redis_host[*]}
	do
		eval $(echo $instance |awk -F '###' '{print "host="$1";port="$2";password="$3";maxmemory="$4}')
		check_redis "$host" "$port" "$password" "$maxmemory"
		if [[ $hl < ${#redis_host[@]} ]];then
			echo ","
		fi	
		hl=$[ $hl + 1 ]
	done
	echo -e "\r\n]"
}
######funciton main (){
	echo -n -e $(date +"%Y-%M-%h %d:%m:%s")":\t" >> var/plugin_redis.log
	trap "echo '脚本执行异常'>> var/plugin_redis.log" ERR
	exec 2> var/plugin_redis.log
	get_host_redis

######}
