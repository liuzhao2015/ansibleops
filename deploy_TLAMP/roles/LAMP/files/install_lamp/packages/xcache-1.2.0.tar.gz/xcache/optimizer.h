#include "php.h"
#include "xcache.h"

void xc_optimize(zend_op_array *op_array TSRMLS_DC);
