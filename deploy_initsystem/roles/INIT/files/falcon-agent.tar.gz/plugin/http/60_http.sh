#!/bin/sh
######################################
# Mon Aug 29 09:30:18 UTC 2016
# by marten wang
######################################

function datamodel(){
	local endpoint=$(hostname)
	local metric=$4
	local tags=$1
	local value=$2
	local types=$3
	echo "{
		'metric': '$metric',
        	'endpoint': '$endpoint',
		'tags': '$tags',
		'value': $value,
		'timestamp': `date +%s`,
		'counterType': '$types',
		'step': 60
	      }
	     "

}

echo "["

#####获取数据########
array=$(curl -s "http://127.0.0.1:8080/server-status"|grep '<dt>.*<\/dt>')
array=(echo $array)
echo $array
#####定义变量########

declare -A A

A['PSG']=${array[22]%%<\/dt>}
A['total_access']=${array[33]}
A['total_traffic']=${array[37]}
A['p_request']=${array[44]##cs*<dt>}
A['p_size']=${array[47]}
A['request_size']=${array[50]}
A['request_process']=${array[52]##<dt>}
A['idel_process']=${array[57]##}

#####端口#####
n=$(ss -antl |grep ':::8080' |grep -v grep |wc -l )
A['Alive_port']=0
if [[ $n -gt 0 ]];then 
	A['Alive_port']='1'
fi

#####进程数######
num=$(ps -ef|grep http |grep -v grep |wc -l)
A['P_NUM']=$num

for key in ${!A[*]}
do
	tags="item=$key"
	value=${A[$key]}
	datamodel $tags $value "GAUGE" "http"
done 

echo "]"
