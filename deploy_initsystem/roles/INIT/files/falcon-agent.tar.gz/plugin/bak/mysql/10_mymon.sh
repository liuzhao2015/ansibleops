#!/bin/sh
#############
# by marten wang
# Mon Aug  1 11:45:59 UTC 2016
#############

###define global variables

mysqlhost="127.0.0.1"
mysqluser="root"
mysqlpass="123456"
mysqlport="3306"


function senddata(){
	local metric=$1
	local value=$2
	local tag=$3
	curl -X POST -d '[{"metric":"'$metric'", "endpoint": "'$(hostname)'", "timestamp": '$(date +%s)', "step": 60,"value":'$value',"counterType": "GAUGE","tags":"'$tag'"}]' http://127.0.0.1:1988/v1/push
}

if [[ -f time.tmp ]];then
	> time.tmp
fi
mysql -u $mysqluser -p$mysqlpass -h $mysqlhost -P $mysqlport -e 'show processlist' |awk '$1 !~ /Id/ && $6 !~ /Dump/'|awk '{print $2,$3,$4,$6,$5}' > time.tmp 2>/dev/null
	
###thread 超过200
value="0"
value=$(wc -l time.tmp|awk '{print $1}')
senddata "thead" "$value" 

##sql语句执行超过50s的

value=0
lined=''
tag=''
count=$(awk '$5 ~ /Query/ && $1 !~ /admin|mha|repl|backup|sphinx_user|root|slowloguser|zabbixMon/' time.tmp |sort -k 4 -rn  |head -1 |awk '{print $4}')
if [[ 'X'$count != 'X' ]];then
	value=$count
fi
senddata "sql_time" "$value" $tag
### sleep 状态 
value=$(awk '$5~/Sleep/' time.tmp |wc -l)
senddata "Sleep_process_sql" $value 

rm -f time.tmp
###通过mymon获取其他状态
cd /usr/local/monitor/open-falcon/agent/plugin/mymon/mymon && ./mymon -c etc/mon.cfg >/dev/null 2>&1 &

