#ifndef CRC64_H
#define CRC64_H

unsigned long long fio_crc64(const unsigned char *, unsigned long);

#endif
