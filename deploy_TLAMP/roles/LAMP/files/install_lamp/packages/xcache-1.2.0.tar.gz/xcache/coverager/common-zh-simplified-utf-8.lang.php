<?php

$strings = array(
		'root'
		=> '开始',
		'Directory'
		=> '目录',
		'File'
		=> '文件',
		'Percent'
		=> '覆盖率',
		'Hits'
		=> '命中',
		'Lines'
		=> '行数',
		'TODO'
		=> '闲置文件',
		'XCache PHP Code Coverage Viewer'
		=> 'XCache PHP 代码覆盖查看器',
		'module'
		=> '模块',
		''
		=> '',
		);

