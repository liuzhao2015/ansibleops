#!/bin/sh
redis_host='yoshop-d-redis-001.mczgdb.0001.use1.cache.amazonaws.com###6379######6000000000
	    yoshop-d-redis-002.mczgdb.0001.use1.cache.amazonaws.com###6379######6000000000'

