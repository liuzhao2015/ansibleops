#!/bin/env python2.6
__auther__="wangmx"
#-*-encoding=utf8-*-
import redis
import sys
import getopt
import time
import sys
####define the var
host = "127.0.0.1"
port = sys.argv[1]


if '__main__'  == __name__:
    try:
	r=redis.Redis(host,int(port))
	if r.ping():
	    print "ok",
	else:
            print "can not connect!!!"
	    sys.exit(1)
	
	data = []
	hostname = socket.gethostname()
	timestamp = int(time.time())
    	step = 60
	
	stat={}
	print "used_memory=%r," %(r.info()['used_memory']),
	stat['used_memory']=r.info()['used_memory']
        print "dbsize=%r," %(r.dbsize()),
        stat['dbsize']=r.dbsize()
	print "used_memory_peak=%r," %(r.info()['used_memory_peak']),
	stat['used_memory_peak']=r.info()['used_memory_peak']
        print "rdb_last_save_time=%r," %(r.info()['rdb_last_save_time']),
	stat['rdb_last_save_time']=r.info()['rdb_last_save_time']
        print "rdb_changes_since_last_save=%r," %(r.info()['rdb_changes_since_last_save']),
	stat['rdb_changes_since_last_save']=r.info()['rdb_changes_since_last_save']
        print "latest_fork_usec=%r, | " %(r.info()['latest_fork_usec']),
	stat['latest_fork_usec']=r.info()['latest_fork_usec']
        print "latest_fork_usec=%r;;;;" %(r.info()['latest_fork_usec']),
	stat['latest_fork_usec']=r.info()['latest_fork_usec']
        print "connected_clients=%r;;;;" %(r.info()['connected_clients']),
	stat['connected_clients']=r.info()['connected_clients']
	
        for key in stat:
            value  = float(stat[key])
            if key in gauges:
                suffix = ''
                vtype  = 'GAUGE'
            else:
                suffix = '_cps'
                vtype = 'COUNTER'

            i = {
                'metric': '%s.%s%s' % (metric, key, suffix),
                'endpoint': endpoint,
                'timestamp': timestamp,
                'step': step,
                'value': value,
                'counterType': vtype,
                'tags': tags
            }
            data.append(i)


    except:
        sys.exit(1)
