#!/bin/sh
######################################
# Mon Aug 29 09:30:18 UTC 2016
# by marten wang
######################################

function datamodel(){
	local endpoint=$(hostname)
	local metric=$4
	local tags=$1
	local value=$2
	local types=$3
	echo "{
		'metric': '$metric',
        	'endpoint': '$endpoint',
		'tags': '$tags',
		'value': $value,
		'timestamp': `date +%s`,
		'counterType': '$types',
		'step': 60
	      }
	     "

}

echo "["

#####获取数据########
port=11211

printf "stats\r\n" | nc 127.0.0.1 $port  > memcache.tmp 

#####used_memory / maxmemory 内存使用率#########
ud=$(grep -w 'bytes' memcache.tmp |awk '{print $3}'|sed 's/\r//g' )
mm=$(grep -w 'limit_maxbytes' memcache.tmp |awk '{print $3}'|sed 's/\r//g' )
ump=$(echo "scale=3;$ud*100/$mm" |bc)

#####定义变量########

declare -A A
A['used_percent']=$ump

#####读写redis#####
OK=$(printf "set checkmemcache_hqyg 0 10 18\r\ncheckmemcache_hqyg\r\n" |nc 127.0.0.1 $port |sed 's/\r\n//g')
A['memcache_alive']=0
if [[ 'X'$OK == 'XSTORED' ]];then
	A['memcache_alive']=2
	value=$(printf "get checkmemcache_hqyg\r\n" |nc 127.0.0.1 11211 |sed -n '2p')
	if [[ 'X'$value == 'Xncheckmemcache_hqyg' ]];then
		A['memcache_alive']=1
	fi
fi



#####端口#####
n=$(ss -antl |grep ":$port" |wc -l )
A['memcache_port']=0
if [[ $n -gt 0 ]];then 
	A['memcache_port']='1'
fi


######连接数######
cuc=$(grep -w 'curr_connections' memcache.tmp |awk '{print $3}' |sed 's/\r//g') 
tc=$(grep -w 'total_connections' memcache.tmp |awk '{print $3}' |sed 's/\r//g') 
ctp=$(echo "scale=3;$cuc*100/$tc" |bc)
A['con_percent']=$ctp



for key in ${!A[*]}
do
	tags="item=$key"
	value=${A[$key]}
	datamodel $tags $value "GAUGE" "memcache"
done 

echo "]"
