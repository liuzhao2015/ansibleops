logFile=serverTest.log
serverTag=`hostname`
if [ ! -d /data/BrienTest ]; then
mkdir -p /data/BrienTest
fi
echo $serverTag
echo "*****CFQ**********" >> $logFile

echo cfq > /sys/block/sda/queue/scheduler
#echo cfq > /sys/block/sdb/queue/scheduler

echo "IO scheduler of sda is:" >> $logFile
cat /sys/block/sda/queue/scheduler >> $logFile

#echo "IO scheduler of sdb is:" >> $logFile
#cat /sys/block/sdb/queue/scheduler >> $logFile

echo "start FIO test" `date` >> $logFile

fio --output=${serverTag}_fio_result_cfq.log fio_test_all.spc

echo "end FIO test" `date` >> $logFile


echo "*****DEADLINE**********" >> $logFile

echo deadline > /sys/block/sda/queue/scheduler
#echo deadline > /sys/block/sdb/queue/scheduler

echo "IO scheduler of sda is:" >> $logFile
cat /sys/block/sda/queue/scheduler >> $logFile

#echo "IO scheduler of sdb is:" >> $logFile
#cat /sys/block/sdb/queue/scheduler >> $logFile

echo "start FIO test" `date` >> $logFile

fio --output=${serverTag}_fio_result_deadline.log fio_test_all.spc

echo "end FIO test" `date` >> $logFile

exit
echo "********memory*********" >> $logFile
echo "start memory test " `date` >> $logFile

sysbench --num-threads=32 --max-requests=0 --max-time=1200 --test=memory --memory-block-size=4K --memory-total-size=1000G --memory-scope=global --memory-oper=read --memory-access-mode=seq run | tee sysbench_memory_read_seq.log 

sysbench --num-threads=32 --max-requests=0 --max-time=1200 --test=memory --memory-block-size=4K --memory-total-size=1000G --memory-scope=global --memory-oper=read --memory-access-mode=rnd run | tee sysbench_memory_read_rnd.log

sysbench --num-threads=32 --max-requests=0 --max-time=1200 --test=memory --memory-block-size=4K --memory-total-size=1000G --memory-scope=global --memory-oper=write --memory-access-mode=seq run | tee sysbench_memory_write_seq.log

sysbench --num-threads=32 --max-requests=0 --max-time=1200 --test=memory --memory-block-size=4K --memory-total-size=1000G --memory-scope=global --memory-oper=write --memory-access-mode=rnd run | tee sysbench_memory_write_rnd.log

echo "end memory test" `date` >> $logFile

echo "********CPU********" >> $logFile
echo "start cpu test " `date` >> $logFile

sysbench --num-threads=32 --max-time=0 --test=cpu --cpu-max-prime=5000000 run | tee sysbench_cpu.log


sysbench --num-threads=400 --max-time=0 --test=threads --thread-yields=500000 --thread-locks=4 run | tee sysbench_threads.log


sysbench --num-threads=400 --max-time=0 --test=mutex --mutex-num=250 --mutex-locks=3000000 run | tee sysbench_mutex.log

echo "end cpu test" `date` >> $logFile


