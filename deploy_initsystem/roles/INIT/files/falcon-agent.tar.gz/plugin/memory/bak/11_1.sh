#/bin/sh


#echo  $(date +"%Y%m%d %H:%M:%S")  >> mem.tmp
ps aux  >> mem1111111111111111111111.tmp
echo '[{"endpoint": "host01", "tags": "", "timestamp": 1431349763, "metric": "sys.ntp.offset", "value": 0.73699999999999999, "counterType": "GAUGE", "step": 600}]'
